import shutil
import flgo
import os


algorithm = ['fedtest.py']
benchmark = []
simulator = []
path = flgo.__file__
category = ''

for root, _, files in os.walk(".", topdown=False):
    for name in files:
        if name in algorithm:
            tar, category = name, 'algorithm'
        elif name in benchmark:
            tar, category = name, 'benchmark'
        elif name in simulator:
            tar, category = name, 'system_simulator'
if category != '':
    temp = path.split('_')
    path = temp[0] + 'algorithm'
    shutil.copy(tar, path)
else:
    print('No standard plugin founded. You could move it to ' + path.split('_')[0] + ' manually')



