## **How to use the plug-ins**


Here are two ways to make a plug-in work correctly.If you download *flgo* as a python package using *pip install flgo*, choose any of the following methods. Otherwise, please use the manual method.


### **Manual configuration**

- Locate the flgo
- Move the Unzipped files to the subfolder according to the type of the plug-in *e.g. algorithm*.

### **Automatic configuration**
- Run the *find_path.py* under a virtual environment with flgo installed.
 
### *P.S. The data for the benchmark needs to be downloaded manually。*
